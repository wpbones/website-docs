<?php return array('dependencies' => array('react', 'wp-i18n'), 'version' => '0126f17a170a19e69833');
