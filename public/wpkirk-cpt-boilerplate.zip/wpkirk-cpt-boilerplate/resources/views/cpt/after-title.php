<?php
// in $startship you will have the post object

if (!defined('ABSPATH')) exit;
?>

<h3>
  <?php _e('Any view after the title', 'wp-kirk'); ?>
  <?php echo $starship->ID ?>
</h3>