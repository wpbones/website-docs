=== WP Kirk Options Boilerplate ===
Contributors: gfazioli
Donate link: https://wpbones.com/
Tags: template, wpbones
Requires at least: 6.2
Tested up to: 6.6
Stable tag: 1.9.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Bones Options Boilerplate WordPress plugin.

== Description ==

WP Bones Options Boilerplate plugin

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the entire content of plugin archive to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress (deactivate and reactivate if you're upgrading).
3. Done. Enjoy.

== Frequently Asked Questions ==

= What is WP Bones framework ? =

See detail to  ([WP Bones](https://wpbones.com/)).

== Screenshots ==

Your screenshot

== Changelog ==

Your changelog

== Upgrade Notice ==

Your upgrade notice