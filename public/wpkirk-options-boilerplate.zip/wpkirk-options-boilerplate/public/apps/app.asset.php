<?php return array('dependencies' => array('react', 'wp-i18n'), 'version' => 'aa2ab096b44cc1c0955f');
