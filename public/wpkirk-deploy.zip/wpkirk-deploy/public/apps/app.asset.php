<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '7511694eb688bd0e332e');
