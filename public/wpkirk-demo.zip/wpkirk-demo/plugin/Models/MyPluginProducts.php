<?php

namespace WPKirk\Models;

use WPKirk\WPBones\Database\Model;

class MyPluginProducts extends Model
{
  /**
 * You may comment out this property if you want to use the class name.
 *
 * @var string The table associated with the model.
 */
//protected $table = 'my_plugin_products';
}
