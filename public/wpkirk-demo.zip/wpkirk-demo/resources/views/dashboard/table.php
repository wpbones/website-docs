<?php if (!defined('ABSPATH')) {
  exit();
} ?>

<div class="wrap">

  <?php echo $table; ?>

</div>
