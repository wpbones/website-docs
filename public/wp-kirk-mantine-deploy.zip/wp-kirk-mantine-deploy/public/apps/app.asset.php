<?php return array('dependencies' => array('react', 'react-dom'), 'version' => 'baf951b312a55fe73339');
