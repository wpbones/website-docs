<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => 'f0132065ad996bfecace');
