<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '8a80dded91e01bb6e8d5');
