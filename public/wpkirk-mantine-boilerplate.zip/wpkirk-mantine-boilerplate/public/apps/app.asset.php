<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => '7108e8ce8f3a2cb88b1e');
