=== WP Kirk Mantine Boilerplate ===
Contributors: gfazioli
Donate link: https://wpbones.com/
Tags: template, wpbones
Requires at least: 6.6
Tested up to: 6.4.3
Stable tag: 2.0.11
License: MIT
License URI: https://opensource.org/licenses/MIT

WP Bones Mantine Boilerplate WordPress plugin.

== Description ==

WP Bones Mantine Boilerplate plugin

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the entire content of plugin archive to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress (deactivate and reactivate if you're upgrading).
3. Done. Enjoy.

== Frequently Asked Questions ==

= What is WP Bones framework ? =

See detail to  ([WP Bones](https://wpbones.com/)).

== Screenshots ==

Your screenshot

== Changelog ==

Your changelog

== Upgrade Notice ==

Your upgrade notice