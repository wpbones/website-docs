<?php

namespace WPKirk\Http\Controllers\Dashboard;

use WPKirk\Http\Controllers\Controller;

class DashboardController extends Controller
{
  public function index()
  {
    $nonce = wp_create_nonce('wp-kirk-mantine');

    return WPKirk()
      ->view('dashboard.index')
      ->withAdminStyle('prism')
      ->withAdminScript('prism')
      ->withAdminStyle('wp-kirk-common')
      ->withAdminAppsScript('mantine-ui', true)
      ->withInlineScript('mantine-ui', 'window.WPKirkMantine = ' . wp_json_encode(['nonce' => $nonce]) . ';', 'before');
  }
}
