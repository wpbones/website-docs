<?php

/*
|--------------------------------------------------------------------------
| Plugin deactivation
|--------------------------------------------------------------------------
|
| This file is included when the plugin is deactivated.
| Usually here you may enter a flush_rewrite_rules();
|
*/

flush_rewrite_rules();
