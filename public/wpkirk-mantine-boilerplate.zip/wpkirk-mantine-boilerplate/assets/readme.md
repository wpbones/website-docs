## Assets

Here you'll find some useful assets to publish your plugin in the WordPress repository.
You can delete this folder in your trnk before submitting.

You should provides the following files:

 * icon-256x256.png
 * icon-128x128.png
 * banner-1544x500.jpg
 * banner-772x256.jpg
 
Also, you can provides some screenshot:
 
 * screenshot-1.jpg
 * screenshot-2.jpg
 * ...