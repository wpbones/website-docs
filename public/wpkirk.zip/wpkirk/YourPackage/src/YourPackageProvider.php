<?php

namespace WPKirk\YourPackage;

class YourPackageProvider
{
  public static function yourPackageMethod()
  {
    echo 'Hello from YourPackageProvider';
  }
}
