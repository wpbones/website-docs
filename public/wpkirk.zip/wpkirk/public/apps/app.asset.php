<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '2d6f6b141f5e9a9eff72');
