<?php

function my_simple_function()
{
  echo "Hello, I'm a simple function!";
}
