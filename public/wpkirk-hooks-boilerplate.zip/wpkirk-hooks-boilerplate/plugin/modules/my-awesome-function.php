<?php

return function () {
  echo "Hello, I'm a awesome function!";
};
