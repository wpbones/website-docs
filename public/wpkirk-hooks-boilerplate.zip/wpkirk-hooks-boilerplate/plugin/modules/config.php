<?php

return [
  'controller' =>
  'WPKirk\Http\Controllers\Examples\ExampleController',
  'mul' => function ($a, $b) {
    return $a * $b;
  }
];
