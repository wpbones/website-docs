<?php

/**
 * You may use this file to define your own hooks.
 * This file, and any other file in this directory, will be automatically included in the plugin.
 */

function my_hooks()
{
  echo "Hello, World!";
}
