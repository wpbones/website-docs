<?php return array('dependencies' => array('react'), 'version' => '713a5a08caf0c3547348');
