<?php

namespace WPKirk\Http\Controllers;

use WPKirk\WPBones\Routing\Controller as BaseController;

if (!defined('ABSPATH')) {
    exit();
}

abstract class Controller extends BaseController
{
}
