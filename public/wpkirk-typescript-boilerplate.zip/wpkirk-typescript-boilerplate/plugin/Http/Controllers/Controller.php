<?php

namespace WPKirk\Http\Controllers;

use WPKirk\WPBones\Routing\Controller as BaseController;

abstract class Controller extends BaseController
{
}
