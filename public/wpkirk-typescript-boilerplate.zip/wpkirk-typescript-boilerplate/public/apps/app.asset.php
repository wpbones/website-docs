<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '67cf0217a3c5370a1eee');
