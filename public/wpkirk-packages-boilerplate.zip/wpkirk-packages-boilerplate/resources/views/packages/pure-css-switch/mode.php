<?php $switch = WPKirk\PureCSSSwitch\Html\HtmlTagSwitchButton::useSwitch(); ?>

<?php echo $switch->name('mode-select')
  ->mode('select')
  ->right_label('Square')
  ->left_label('Square'); ?>

<hr />