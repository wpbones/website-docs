<?php $switch = WPKirk\PureCSSSwitch\Html\HtmlTagSwitchButton::useSwitch(); ?>

<?php echo $switch->name('test-switch-2')->right_label('Swipe me'); ?>
