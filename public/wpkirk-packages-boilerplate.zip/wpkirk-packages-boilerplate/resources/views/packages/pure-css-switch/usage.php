<!-- simple usage -->
<?php echo WPKirk\PureCSSSwitch\Html\HtmlTagSwitchButton::name('test-switch-1')
  ->right_label('Swipe me'); ?>