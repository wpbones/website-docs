<div class="wrap">

  <?php echo $table; ?>

</div>