# Pure CSS Tabs for WP Bones

<div align="center">

[![Latest Stable Version](https://poser.pugx.org/wpbones/pure-css-tabs/v/stable?style=for-the-badge)](https://packagist.org/packages/wpbones/pure-css-tabs) &nbsp;
[![Latest Unstable Version](https://poser.pugx.org/wpbones/pure-css-tabs/v/unstable?style=for-the-badge)](https://packagist.org/packages/wpbones/pure-css-tabs) &nbsp;
[![Total Downloads](https://poser.pugx.org/wpbones/pure-css-tabs/downloads?style=for-the-badge)](https://packagist.org/packages/wpbones/pure-css-tabs) &nbsp;
[![License](https://poser.pugx.org/wpbones/pure-css-tabs/license?style=for-the-badge)](https://packagist.org/packages/wpbones/pure-css-tabs) &nbsp;
[![Monthly Downloads](https://poser.pugx.org/wpbones/pure-css-tabs/d/monthly?style=for-the-badge)](https://packagist.org/packages/wpbones/pure-css-tabs)


</div>

This package provides a simple way to create tabs with pure CSS for WordPress/WP Bones.

![Pure CSS Tabs for WP Bones](https://github.com/user-attachments/assets/e8143a4c-8694-420b-b281-c0fb0d080f5a)

 ## Requirements

This package works with a WordPress plugin written with [WP Bones framework library](https://github.com/wpbones/WPBones).

## Installation

You can install third party packages by using:

```sh copy
php bones require  wpbones/pure-css-tabs
```

I advise to use this command instead of `composer require` because doing this an automatic renaming will done.

You can use composer to install this package:

```sh copy
composer require  wpbones/pure-css-tabs
```

You may also to add `" wpbones/pure-css-tabs": "~0.7"` in the `composer.json` file of your plugin:

```json copy filename="composer.json" {4}
  "require": {
    "php": ">=7.4",
    "wpbones/wpbones": "~1.9",
    "wpbones/pure-css-tabs": "~1.1"
  },
```

and run

```sh copy
composer install
```

## Enqueue for Controller

You can use the provider to enqueue the styles.

```php copy
public function index()
{
  // enqueue the minified version
  PureCSSTabsProvider::enqueueStyles();

  // ...

}
```

## PureCSSTabsProvider

This is a static class autoloaded by composer. You can use it to enqueue or get the styles path:

```php copy
// enqueue the minified version
PureCSSTabsProvider::enqueueStyles();

// enqueue the flat version
PureCSSTabsProvider::enqueueStyles( false );

// return the absolute path of the minified css
PureCSSTabsProvider::css();

// return the absolute path of the flat css
PureCSSTabsProvider::css();
```

## HTML markup

```html copy
<!-- main tabs container -->
<div class="wpbones-tabs">

  <!-- first tab -->
  <input id="tab-1" type="radio" name="tabs" checked="checked" aria-hidden="true">
  <label for="tab-1" tabindex="0"><?php _e( 'Database' ) ?</label>
  <div class="wpbones-tab">
    <h3>Content</h3>
  </div>

  <!-- second tab -->
  <input id="tab-2" type="radio" name="tabs" aria-hidden="true">
  <label for="tab-2" tabindex="0"><?php _e( 'Posts' ) ?></label>
  <div class="wpbones-tab">
    <h3>Content</h3>
  </div>

  <!-- son on... -->

</div>
```

Of course, you may use the **fragment** feature to include the single tabs:

```html copy
<!-- main tabs container -->
<div class="wpbones-tabs">

  <!-- first tab -->
  <?php echo WPkirk()->view( 'folder.tab1' ) ?>

  <!-- second tab -->
  <?php echo WPkirk()->view( 'folder.tab2' ) ?>

  <!-- son on... -->

</div>
```
 In `/folder/tab1.php` you just insert the following markup:

 ```html copy
<!-- first tab -->
<input id="tab-1" type="radio" name="tabs" checked="checked" aria-hidden="true">
<label for="tab-1" tabindex="0"><?php _e( 'Database' ) ?></label>
<div class="wpbones-tab">
  <h3>Content</h3>
</div>
```

## Customize

Of course, you can edit both of CSS or LESS files in order to change the appearance of tabs.
In the LESS file, you'll find the color variable as well.

```less copy
@wpbones-tab-border-color : #aaa;
@wpbones-tab-responsive-accordion-border : #ddd;
@wpbones-tab-disabled : #ddd;
@wpbones-tab-content-color : #fff;
```

> 💡 Anyway, the best way to customize your tabs is override the default styles. Otherwise, when an update will be done you'll lose your customization.

## Helper

In addition, you can use some methods provided by `PureCSSTabsProvider` class.
In your HTML view you might use:

```php copy
    /**
     * Display tabs by array
     *
     *     self::tabs(
     *       'tab-1' => [ 'label' => 'Tab 1', 'content' => 'Hello', 'selected' => true ],
     *       'tab-2' => [ 'label' => 'Tab 1', 'content' => 'Hello' ],
     *       ...
     *     );
     *
     * @param array $array
     */
    WPKirk\PureCSSTabs\PureCSSTabsProvider::tabs(
      'tab-1' => [ 'label' => 'Tab 1', 'content' => 'Hello', 'selected' => true ],
      'tab-2' => [ 'label' => 'Tab 1', 'content' => 'Hello' ],
      ...
    );
```

Also, you can use `openTab()` and `closeTab()` methods:

```php copy
  /**
   * Display the open tab.
   *
   * @param string|array  $label    The label of tab or un array with [label, group]
   * @param null          $id       Optional. ID of tab. If null, will sanitize_title() the label.
   * @param bool          $selected Optional. Default false. TRUE for checked.
   * @param string        $group    Optional. Group of tabs when you want to handle multiple tab in the same view. Default 'tabs'

   */
   public static function openTab( $label, $id = null, $selected = false ) {}
```

```html copy
<div class="wpbones-tabs">

  <?php WPKirk\PureCSSTabs\PureCSSTabsProvider::openTab( 'Tab 1', null, true ) ?>
    <h2>Hello, world! I'm the content of tab-1</h2>
  <?php WPKirk\PureCSSTabs\PureCSSTabsProvider::closeTab ?>

  <?php WPKirk\PureCSSTabs\PureCSSTabsProvider::openTab( 'Tab 2' ) ?>
    <h2>Hello, world! I'm the content of tab-2</h2>
  <?php WPKirk\PureCSSTabs\PureCSSTabsProvider::closeTab ?>

</div>
```

You may also use the hook approach by using `::useTabs()`

```php copy
<?php [$openTabs, $closeTabs] = WPKirk\PureCSSTabs\PureCSSTabsProvider::useTabs() ?>

<div class="wpbones-tabs">

  <!-- first tab -->
  <?php $openTabs(['Settings', 'hook'], null, true); ?>

  <div>
    <h3>Content for Settings</h3>
  </div>

  <?php $closeTabs(); ?>

  <!-- second tab -->
  <?php $openTabs(['Dashboard', 'hook']); ?>

  <div>
    <h3>Content for Dashboard</h3>
  </div>

  <?php $closeTabs(); ?>

  <!-- son on... -->

</div>
```

> 👆 Remember, in the example above I have used `WPKirk` base namespace. You should replace it with your own namespace.
