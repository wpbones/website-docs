<?php

/*
|--------------------------------------------------------------------------
| Custom configuration
|--------------------------------------------------------------------------
|
| This is a example of custom configuration. You may get this configuration
| by plugin instance.
| For example in a view you can use `$this->config( 'custom.sample' )`.
|
*/

return [ ];