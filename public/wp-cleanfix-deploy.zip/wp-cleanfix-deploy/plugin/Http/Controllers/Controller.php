<?php

namespace WPCleanFix\Http\Controllers;

use WPCleanFix\WPBones\Routing\Controller as BaseController;

abstract class Controller extends BaseController {

}